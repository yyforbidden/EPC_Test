from twisted.internet.protocol import Protocol, ClientFactory
from twisted.internet import defer
from twisted.internet.error import ConnectError
from twisted.trial.unittest import TestCase

class KB_ClientProtocol(Protocol):
    
    buffer = ''
    
    def connectionMade(self):
        self.send_start_test()
        
        
    def connectionLost(self):
        pass
    
    
    def dataReceived(self, data):
        self.buffer += data
        for rsp in self._parse():
            self.response_received(rsp)
    
    
    def response_received(self, rsp):
        self.factory.reponse_received(rsp)
    
    
class KB_ClientFactory(ClientFactory):
    
    def __init__(self):
        self.d = defer.Deferred()
        
        
    def response_received(self, rsp):
        self.d.callback(rsp)


class KB_Client:
    
    def start_test(self):
        pass
    
    
    def query(self, msg):
        pass
    
    
    def stop_test(self):
        pass
        
    
class KB_ControllerTest(TestCase):
    
    def setUp(self):
        pass
    
    
    def tearDown(self):
        pass
