from test_context import *
from test_script import *

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()