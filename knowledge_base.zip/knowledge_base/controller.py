from twisted.internet.protocol import Protocol, ServerFactory
import struct
import json
import traceback
from context import ContextManager
from script import ScriptManager


class Query:
    
    def __init__(self, req, sm, cm, p):
        
        self.request = req
        self.script_manager = sm
        self.context_manager = cm
        self.protocol = p
        self.handlers = {'StartTest': self.on_start_test,
                         'StopTest': self.on_stop_test,
                         'QuerySend': self.on_query_send,
                         'QueryReceive': self.on_query_receive}
        cmd = req['command']
        self.handler = self.handlers[cmd]
        
        
    def process(self):
        self.handler(self.request['message'])
        
        
    def on_start_test(self, msg):
        pass
    
    
    def on_stop_test(self, msg):
        self.context_manager.clear_test()
        self.protocol.loseConnection()
    
        
    def on_query_send(self, msg):
        rsp = {'command': 'AnswerSend',
               'message': msg}
        try:
            s = self.script_manager.find_script(msg)
        except Exception:
            return rsp
        
        if not s:
            return rsp
        
        try:
            rsp_msg = s.run(msg, self.context_manager)
            rsp = {'command': 'AnswerSend',
                   'message': rsp_msg}
        except Exception:
            info = traceback.format_exc()
            rsp = {'command': 'Exception',
                   'reason': info}
        return rsp
    
    
    def on_query_receive(self, msg):
        try:
            s = self.script_manager.find_script(msg)
        except Exception:
            info = traceback.format_exc()
            rsp = {'command': 'Exception',
                   'reason': info}
            return rsp
        
        if not s:
            rsp = {'command': 'Exception',
                   'reason': 'Cannot find script'}
            return rsp
        
        try:
            rsp_msg = s.run(msg, self.context_manager)
            rsp = {'command': 'AnswerSend',
                   'message': rsp_msg}
        except Exception:
            info = traceback.format_exc()
            rsp = {'command': 'Exception',
                   'reason': info}
        return rsp


class KB_QueryProtocol(Protocol):
    
    buffer = ''
    
    def _parse(self, data):
        self.buffer += data
        while True:
            if len(self.buffer) <= 4:
                break
            l = struct.unpack('!I', self.buffer[:4])
            if l > len(self.buffer)-4:
                break
            q, self.buffer = self.buffer[4:l], self.buffer[l:]
            q = json.loads(q)
            yield q
            
            
    def _send(self, rsp):
        s = json.dumps(rsp)
        l = len(s)
        s = struct.pack('!I', l) + s
        self.transport.write(s)
            
            
    def stringRecieved(self, data):
        for req in self._parse(data):
            q = Query(req, self.script_manager, self.context_manager)
            rsp = q.process()
            if rsp:
                self._send(rsp)
            
            
class KB_QueryFactory(ServerFactory):
    
    protocol = KB_QueryProtocol
    
    def __init__(self, sp, cp):
        self.script_manager = ScriptManager(sp)
        self.context_path = cp
        
        
    def buildProtocol(self, addr):
        p = ServerFactory.buildProtocol(self, addr)
        p.script_manager = self.script_manager
        p.context_manager = ContextManager(self.context_path)
        return p
    

class Controller:
    
    def __init__(self, port, script_path, context_path):
        self.port = port
        self.script_path = script_path
        self.context_path = context_path
        
    def run(self):
        kb_query_factory = KB_QueryFactory(self.script_path,
                                           self.context_path)
        from twisted.internet import reactor
        reactor.listenTCP(self.port, kb_query_factory)
        reactor.run()