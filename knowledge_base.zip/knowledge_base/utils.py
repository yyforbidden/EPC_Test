def log(s):
    print s